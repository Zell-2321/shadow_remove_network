import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
import matplotlib.pyplot as plt

class ShadowRemovalDataset(Dataset):
    def __init__(self, root_dir, transform=None, masked_img = False):
        self.root_dir = root_dir
        self.transform = transform
        self.masked_img = masked_img
        self.image_filenames = os.listdir(os.path.join(root_dir, root_dir+'_A'))
    
    def __len__(self):
        return len(self.image_filenames)

    def __getitem__(self, idx):
        if self.masked_img:
            img_name = self.image_filenames[idx]
            input_image = Image.open(os.path.join(self.root_dir, self.root_dir+'_A', img_name)).convert("RGB")
            mask_image = Image.open(os.path.join(self.root_dir, self.root_dir+'_B', img_name)).convert("RGB")
            target_image = Image.open(os.path.join(self.root_dir, self.root_dir+'_C', img_name)).convert("RGB")
            
            if self.transform:
                input_image = self.transform(input_image)
                mask_image = self.transform(mask_image)
                target_image = self.transform(target_image)
            
            input_data = torch.cat((input_image, mask_image), dim=0)
            
            return input_data, target_image
        else:   
            img_name = self.image_filenames[idx]
            input_image = Image.open(os.path.join(self.root_dir, self.root_dir+'_A', img_name)).convert("RGB")
            target_image = Image.open(os.path.join(self.root_dir, self.root_dir+'_B', img_name)).convert("RGB")
            
            if self.transform:
                input_image = self.transform(input_image)
                target_image = self.transform(target_image)
            
            return input_image, target_image
        
class UNet_mask(nn.Module):
    def __init__(self):
        super(UNet_mask, self).__init__()
        # 编码器部分
        self.name = "UNet_mask"
        self.encoder = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        # 解码器部分
        self.decoder = nn.Sequential(
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 3, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()  # 确保输出在[0,1]之间
        )

    def forward(self, x):
        x = self.encoder(x)
        x = nn.functional.interpolate(x, scale_factor=2, mode="bilinear", align_corners=True)
        x = self.decoder(x)
        return x
    
class UNet(nn.Module):
    def __init__(self):
        super(UNet, self).__init__()
        # 编码器部分
        self.name = "UNet"
        self.encoder = nn.Sequential(
            nn.Conv2d(6, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2, 2)
        )
        # 解码器部分
        self.decoder = nn.Sequential(
            nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 3, kernel_size=3, stride=1, padding=1),
            nn.Sigmoid()  # 确保输出在[0,1]之间
        )

    def forward(self, x):
        x = self.encoder(x)
        x = nn.functional.interpolate(x, scale_factor=2, mode="bilinear", align_corners=True)
        x = self.decoder(x)
        return x
    
def train_model(model, train_loader, criterion, optimizer, num_epochs, device):
    for epoch in range(num_epochs):
        model.train()
        for inputs, targets in train_loader:
            inputs, targets = inputs.to(device), targets.to(device)
            
            # 前向传播
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            
            # 反向传播与优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
        
        print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}")
        torch.save(model.state_dict(), f"model/{model.name}_epoch_{epoch+1}.pth")